package com.example.harshal.inclass6;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Harshal on 2/19/2018.
 */

public class GetDataAsync extends AsyncTask<String, Void, ArrayList<Articles>> {
    RequestParams mParams;
    HandleData handleData;

    public GetDataAsync(RequestParams params, HandleData handleData) {
        this.handleData = handleData;
        mParams = params;
    }

    @Override
    protected ArrayList<Articles> doInBackground(String... params) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        ArrayList<Articles> result = new ArrayList<>();
        try {
            URL url = new URL(mParams.getEncodedUrl(params[0]));
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                Log.d("demo", "Url in doinBackgrous" + IOUtils.toString(connection.getInputStream(), "UTF8"));
                Log.d("demo", "json = " + json);
                JSONObject root = new JSONObject(json);
                JSONArray articlesJsonArray = root.getJSONArray("articles");

                for (int i = 0; i < articlesJsonArray.length(); i++) {
                    JSONObject articlesJson = articlesJsonArray.getJSONObject(i);
                    Articles articles = new Articles();
                    articles.author = articlesJson.getString("author");
                    articles.title = articlesJson.getString("title");
                    if(articlesJson.getString("description") == "null"){
                        articles.description = "";
                    }
                    else{
                        articles.description = articlesJson.getString("description");
                    }
                    articles.url = articlesJson.getString("url");
                    articles.urlToImage = articlesJson.getString("urlToImage");
                    articles.publishedAt = articlesJson.getString("publishedAt");

                    JSONObject sourceJson = articlesJson.getJSONObject("source");
                    Source source = new Source();
                    source.id = sourceJson.getString("id");
                    source.name = sourceJson.getString("name");

                    articles.source = source;

                    result.add(articles);
                }


//                JSONArray newsJsonArray = root.getJSONArray("object");
//
//                for(int i=0;i<newsJsonArray.length();i++) {
//
//
//                    Log.d("demo" ,"inside for ");
//                    JSONObject newsJson = newsJsonArray.getJSONObject(i);
//                    News news = new News();
//                    news.status =  newsJson.getString("status");
//                    news.totalResults = newsJson.getInt("totalResults");
//
//
//                    JSONObject articlesJson = newsJson.getJSONObject("articles");
//                    Articles articles = new Articles();
//                    articles.author = articlesJson.getString("author");
//                    articles.title = articlesJson.getString("title");
//                    articles.description = articlesJson.getString("description");
//                    articles.url = articlesJson.getString("url");
//                    articles.urlToImage = articlesJson.getString("urlToImage");
//                    articles.publishedAt = articlesJson.getString("publishedAt");
//
//                    JSONObject sourceJson = newsJson.getJSONObject("source");
//                    Source source = new Source();
//                    source.id = sourceJson.getString("id");
//                    source.name = sourceJson.getString("name");
//
//                    articles.source = source;
//                    news.articles = articles;
//
//                    Log.d("demo", "news = " + news.toString());
//                    result.add(news);
//
//                    Log.d("demo", "result = " + result.toString());
//                    Person person = new Person();
//                    person.name = personJson.getString("name");
//                    person.id = personJson.getLong("id");
//                    person.age = personJson.getInt("age");

//                    JSONObject addressJson = personJson.getJSONObject("address");
//                    Address address = new Address();

//                    address.line1 = addressJson.getString("line1");
//                    address.city = addressJson.getString("city");
//                    address.state = addressJson.getString("state");
//                    address.zip = addressJson.getString("zip");

                // person.address = address;
                //result.add(person);
            }
        } catch (IOException e1) {
            e1.printStackTrace();
        } catch (JSONException e1) {
            e1.printStackTrace();
        }  finally {
            if (connection != null) {
                connection.disconnect();
            }
//
        }
        return result;
    }

    @Override
    protected void onPreExecute() {
        MainActivity.progressDialog.setMessage("Loading News");
        MainActivity.progressDialog.setCancelable(false);
        MainActivity.progressDialog.setMax(10000);
        MainActivity.progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        MainActivity.progressDialog.show();
    }

    @Override
    protected void onPostExecute(ArrayList<Articles> result) {

        MainActivity.progressDialog.dismiss();
        if (result.size() > 0) {
            Log.d("demo", "JSON Parsing" + result.toString());
            handleData.handledata(result);
        } else {
            Log.d("demo", "nothing to be returned");
        }
//        if(result != null && !result.matches(""))
//        {
//            tempUrl = result;
//            //Log.d("demo","Url in OnPostExecute GetParamsUsingAsync " + tempUrl);
//            //new GetImageAsync(MainActivity.this , result, count).execute();
//            new GetImageAsync(MainActivity.this , tempUrl).execute();
//            //for(int i = 0; i<100000 ; i++){}
//            //progressDialog.dismiss();
//        }
//        else
//        {
//            Toast.makeText(MainActivity.this, "No Images Found", Toast.LENGTH_SHORT).show();
//            Log.d("demo","nothing to be returned GetDataUsingParamsAsync");
//            imageView.setImageDrawable(null);
//            progressDialog.dismiss();
//            nextImageView.setEnabled(false);
//            previousImageView.setEnabled(false);
//        }
    }
    public static interface HandleData
    {
        public void handledata(ArrayList<Articles> articles);
    }


}
